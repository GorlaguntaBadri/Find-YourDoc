import { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import Header from './components/Header'
import FilterPanel from './components/FilterPanel'
import DoctorList from './components/DoctorList'
import { useDoctors } from './hooks/useDoctors'

function App() {
  const [searchParams, setSearchParams] = useSearchParams()
  const { doctors, isLoading, error } = useDoctors()
  const [searchTerm, setSearchTerm] = useState('')
  const [consultationType, setConsultationType] = useState('')
  const [selectedSpecialties, setSelectedSpecialties] = useState([])
  const [sortBy, setSortBy] = useState('')

  // Initialize state from URL on component mount
  useEffect(() => {
    if (searchParams.has('search')) {
      setSearchTerm(searchParams.get('search'))
    }
    if (searchParams.has('consultType')) {
      setConsultationType(searchParams.get('consultType'))
    }
    if (searchParams.has('specialties')) {
      setSelectedSpecialties(searchParams.get('specialties').split(','))
    }
    if (searchParams.has('sortBy')) {
      setSortBy(searchParams.get('sortBy'))
    }
  }, [])

  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams()
    
    if (searchTerm) {
      params.set('search', searchTerm)
    }
    if (consultationType) {
      params.set('consultType', consultationType)
    }
    if (selectedSpecialties.length > 0) {
      params.set('specialties', selectedSpecialties.join(','))
    }
    if (sortBy) {
      params.set('sortBy', sortBy)
    }
    
    setSearchParams(params)
  }, [searchTerm, consultationType, selectedSpecialties, sortBy, setSearchParams])

  // Filter and sort doctors based on the current filters
  const filteredDoctors = doctors?.filter(doctor => {
    let matchesSearch = true
    let matchesConsultationType = true
    let matchesSpecialties = true

    // Filter by search term
    if (searchTerm) {
      matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase())
    }

    // Filter by consultation type
    if (consultationType === 'Video Consult') {
      matchesConsultationType = doctor.consultationMode.includes('Video Consult')
    } else if (consultationType === 'In Clinic') {
      matchesConsultationType = doctor.consultationMode.includes('In Clinic')
    }

    // Filter by specialties
    if (selectedSpecialties.length > 0) {
      matchesSpecialties = selectedSpecialties.some(specialty => 
        doctor.speciality.includes(specialty)
      )
    }

    return matchesSearch && matchesConsultationType && matchesSpecialties
  }) || []

  // Sort the filtered doctors
  const sortedDoctors = [...filteredDoctors].sort((a, b) => {
    if (sortBy === 'fees') {
      return a.fees - b.fees
    } else if (sortBy === 'experience') {
      return b.experience - a.experience
    }
    return 0
  })

  const handleSearch = (term) => {
    setSearchTerm(term)
  }

  const handleConsultationTypeChange = (type) => {
    setConsultationType(type)
  }

  const handleSpecialtyChange = (specialty, isChecked) => {
    if (isChecked) {
      setSelectedSpecialties(prev => [...prev, specialty])
    } else {
      setSelectedSpecialties(prev => prev.filter(s => s !== specialty))
    }
  }

  const handleSortChange = (sortOption) => {
    setSortBy(sortOption)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        searchTerm={searchTerm} 
        onSearch={handleSearch} 
        doctors={doctors || []} 
      />
      <main className="container mx-auto px-4 py-6 md:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-6">
          <FilterPanel
            consultationType={consultationType}
            onConsultationTypeChange={handleConsultationTypeChange}
            selectedSpecialties={selectedSpecialties}
            onSpecialtyChange={handleSpecialtyChange}
            sortBy={sortBy}
            onSortChange={handleSortChange}
            doctors={doctors || []}
          />
          <DoctorList 
            doctors={sortedDoctors} 
            isLoading={isLoading}
            error={error}
          />
        </div>
      </main>
    </div>
  )
}

export default App