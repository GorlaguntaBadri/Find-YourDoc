const DoctorCard = ({ doctor }) => {
  return (
    <div 
      className="doctor-card bg-white rounded-lg shadow-card p-4 transition-all hover:shadow-card-hover"
      data-testid="doctor-card"
    >
      <div className="flex flex-col md:flex-row gap-4">
        <div className="md:w-1/4 lg:w-1/5">
          <img 
            src={doctor.image || "https://via.placeholder.com/150?text=Doctor"} 
            alt={doctor.name}
            className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover mx-auto md:mx-0"
            onError={(e) => {
              e.target.onerror = null
              e.target.src = "https://via.placeholder.com/150?text=Doctor"
            }}
          />
        </div>
        
        <div className="md:w-3/4 lg:w-4/5">
          <div className="flex flex-col md:flex-row justify-between">
            <div>
              <h3 
                className="text-lg font-semibold text-gray-800"
                data-testid="doctor-name"
              >
                {doctor.name}
              </h3>
              <p 
                className="text-sm text-gray-600 mt-1"
                data-testid="doctor-specialty"
              >
                {Array.isArray(doctor.speciality) ? doctor.speciality.join(', ') : 'No Speciality Listed'}
              </p>
              <p 
                className="text-sm font-medium text-gray-700 mt-2"
                data-testid="doctor-experience"
              >
                {doctor.experience} years of experience
              </p>
            </div>
            
            <div className="mt-3 md:mt-0 text-right">
              <p 
                className="text-lg font-bold text-primary"
                data-testid="doctor-fee"
              >
                ₹{doctor.fees}
              </p>
              <p className="text-sm text-gray-500">Consultation Fee</p>
            </div>
          </div>
          
          <div className="mt-4 border-t pt-4">
            <div className="flex flex-wrap gap-2">
              {Array.isArray(doctor.consultationMode) ? doctor.consultationMode.map((mode, index) => (
                <span 
                  key={index}
                  className={`text-xs font-medium px-3 py-1 rounded-full ${
                    mode === 'Video Consult' 
                      ? 'bg-blue-100 text-blue-800' 
                      : 'bg-green-100 text-green-800'
                  }`}
                >
                  {mode}
                </span>
              )) : null}
            </div>
            
            <div className="mt-4 flex flex-col sm:flex-row gap-2">
              <button className="btn-primary bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition-colors">
                Book Appointment
              </button>
              <button className="btn-secondary border border-primary text-primary px-4 py-2 rounded-md hover:bg-primary/10 transition-colors">
                View Profile
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DoctorCard