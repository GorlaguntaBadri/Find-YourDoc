import DoctorCard from './DoctorCard'
import Spinner from './Spinner'

const DoctorList = ({ doctors, isLoading, error }) => {
  if (isLoading) {
    return (
      <div className="flex-1 flex justify-center items-center min-h-[50vh]">
        <Spinner />
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex-1 p-6 bg-white rounded-lg shadow text-center">
        <p className="text-error font-medium">Error: {error}</p>
        <p className="mt-2">Please try again later or contact support if the problem persists.</p>
      </div>
    )
  }

  if (!doctors || doctors.length === 0) {
    return (
      <div className="flex-1 p-6 bg-white rounded-lg shadow text-center">
        <h2 className="text-xl font-semibold text-gray-700">No doctors found</h2>
        <p className="mt-2 text-gray-600">Try adjusting your filters or search criteria.</p>
      </div>
    )
  }

  return (
    <div className="flex-1">
      <h2 className="text-xl font-semibold mb-4">{doctors.length} Doctor{doctors.length !== 1 ? 's' : ''} Found</h2>
      <div className="space-y-4">
        {doctors.map((doctor) => (
          <DoctorCard key={doctor.id} doctor={doctor} />
        ))}
      </div>
    </div>
  )
}

export default DoctorList