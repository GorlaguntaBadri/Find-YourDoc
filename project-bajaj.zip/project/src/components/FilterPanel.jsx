import { useMemo } from 'react'
import FilterSection from './FilterSection'

const FilterPanel = ({
  consultationType,
  onConsultationTypeChange,
  selectedSpecialties,
  onSpecialtyChange,
  sortBy,
  onSortChange,
  doctors
}) => {
  // Extract all unique specialties from the doctors data
  const allSpecialties = useMemo(() => {
    if (!Array.isArray(doctors)) return []
    
    const specialtiesSet = new Set()
    doctors.forEach(doctor => {
      if (Array.isArray(doctor.speciality)) {
        doctor.speciality.forEach(specialty => {
          specialtiesSet.add(specialty)
        })
      }
    })
    
    return Array.from(specialtiesSet).sort()
  }, [doctors])

  return (
    <aside className="w-full md:w-80 bg-white rounded-lg shadow p-4 h-fit">
      <h2 className="text-lg font-semibold mb-4">Filters</h2>
      
      {/* Consultation Mode Filter */}
      <FilterSection title="Consultation Mode" dataTestId="filter-header-moc">
        <div className="space-y-2">
          <label className="custom-radio block">
            <input
              type="radio"
              name="consultationType"
              data-testid="filter-video-consult"
              checked={consultationType === 'Video Consult'}
              onChange={() => onConsultationTypeChange('Video Consult')}
              className="mr-2"
            />
            <span>Video Consult</span>
          </label>
          <label className="custom-radio block">
            <input
              type="radio"
              name="consultationType"
              data-testid="filter-in-clinic"
              checked={consultationType === 'In Clinic'}
              onChange={() => onConsultationTypeChange('In Clinic')}
              className="mr-2"
            />
            <span>In Clinic</span>
          </label>
        </div>
      </FilterSection>
      
      {/* Specialties Filter */}
      <FilterSection title="Speciality" dataTestId="filter-header-speciality">
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {allSpecialties.map(specialty => (
            <label key={specialty} className="custom-checkbox block">
              <input
                type="checkbox"
                data-testid={`filter-specialty-${specialty.replace(/\s+/g, '-')}`}
                checked={selectedSpecialties.includes(specialty)}
                onChange={(e) => onSpecialtyChange(specialty, e.target.checked)}
                className="mr-2"
              />
              <span>{specialty}</span>
            </label>
          ))}
        </div>
      </FilterSection>
      
      {/* Sort Filter */}
      <FilterSection title="Sort By" dataTestId="filter-header-sort">
        <div className="space-y-2">
          <label className="custom-radio block">
            <input
              type="radio"
              name="sortBy"
              data-testid="sort-fees"
              checked={sortBy === 'fees'}
              onChange={() => onSortChange('fees')}
              className="mr-2"
            />
            <span>Fees (Low to High)</span>
          </label>
          <label className="custom-radio block">
            <input
              type="radio"
              name="sortBy"
              data-testid="sort-experience"
              checked={sortBy === 'experience'}
              onChange={() => onSortChange('experience')}
              className="mr-2"
            />
            <span>Experience (High to Low)</span>
          </label>
        </div>
      </FilterSection>
    </aside>
  )
}

export default FilterPanel