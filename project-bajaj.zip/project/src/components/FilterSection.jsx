import { useState } from 'react'

const FilterSection = ({ title, children, dataTestId }) => {
  const [isOpen, setIsOpen] = useState(true)

  return (
    <div className="mb-6">
      <div 
        className="flex justify-between items-center mb-2 cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 
          className="font-medium text-gray-700" 
          data-testid={dataTestId}
        >
          {title}
        </h3>
        <button 
          className="text-gray-500 focus:outline-none"
          aria-label={isOpen ? 'Collapse' : 'Expand'}
        >
          <svg
            className={`w-5 h-5 transition-transform duration-200 ${isOpen ? 'transform rotate-180' : ''}`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
          </svg>
        </button>
      </div>
      
      <div className={`transition-all duration-200 overflow-hidden ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
        {children}
      </div>
      
      <div className="mt-3 border-b border-gray-200"></div>
    </div>
  )
}

export default FilterSection