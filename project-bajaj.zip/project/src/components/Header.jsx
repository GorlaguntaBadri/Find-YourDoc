import { useState, useEffect, useRef } from 'react'

const Header = ({ searchTerm, onSearch, doctors }) => {
  const [suggestions, setSuggestions] = useState([])
  const [isFocused, setIsFocused] = useState(false)
  const inputRef = useRef(null)
  const suggestionsRef = useRef(null)

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target) && 
          inputRef.current && !inputRef.current.contains(event.target)) {
        setIsFocused(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  const handleInputChange = (e) => {
    const value = e.target.value
    onSearch(value)
    
    // Update suggestions only if we have some input and doctors data
    if (value && doctors.length > 0) {
      const filteredSuggestions = doctors
        .filter(doctor => doctor.name.toLowerCase().includes(value.toLowerCase()))
        .slice(0, 3)
        .map(doctor => doctor.name)
      
      setSuggestions(filteredSuggestions)
    } else {
      setSuggestions([])
    }
  }

  const handleSuggestionClick = (suggestion) => {
    onSearch(suggestion)
    setSuggestions([])
    setIsFocused(false)
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      setIsFocused(false)
    }
  }

  return (
    <header className="bg-white shadow-md sticky top-0 z-10">
      <div className="container mx-auto px-4 py-4 md:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-primary mr-4">DoctorFinder</h1>
          </div>
          
          <div className="relative w-full max-w-md">
            <input
              type="text"
              ref={inputRef}
              data-testid="autocomplete-input"
              className="w-full p-2 pl-10 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-primary focus:border-primary"
              placeholder="Search for doctors..."
              value={searchTerm}
              onChange={handleInputChange}
              onFocus={() => setIsFocused(true)}
              onKeyDown={handleKeyDown}
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            
            {isFocused && suggestions.length > 0 && (
              <ul 
                ref={suggestionsRef}
                className="absolute mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg z-10 suggestion-dropdown"
              >
                {suggestions.map((suggestion, index) => (
                  <li 
                    key={index}
                    data-testid="suggestion-item"
                    className="px-4 py-2 hover:bg-gray-100 cursor-pointer transition-colors"
                    onClick={() => handleSuggestionClick(suggestion)}
                  >
                    {suggestion}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header