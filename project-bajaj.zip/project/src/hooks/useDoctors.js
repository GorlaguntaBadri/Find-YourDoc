import { useState, useEffect } from 'react'

export const useDoctors = () => {
  const [doctors, setDoctors] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        setIsLoading(true)
        const response = await fetch('https://srijandubey.github.io/campus-api-mock/SRM-C1-25.json')
        
        if (!response.ok) {
          throw new Error(`Failed to fetch doctors: ${response.status}`)
        }
        
        const data = await response.json()
        setDoctors(data)
      } catch (err) {
        setError(err.message)
        console.error('Error fetching doctors:', err)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDoctors()
  }, [])

  return { doctors, isLoading, error }
}